#ifndef CREATE_CONNECTION_H
#define CREATE_CONNECTION_H

#include <QObject>
#include <QWidget>

class Create_connection : public QWidget
{
    Q_OBJECT
public:
    explicit Create_connection(QWidget *parent = nullptr);

signals:

};

#endif // CREATE_CONNECTION_H
