#include "create_connection.h"

Create_connection::Create_connection(QWidget *parent)
    : QWidget{parent}
{

}
